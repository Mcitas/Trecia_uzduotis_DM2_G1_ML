var class_zmogus =
[
    [ "abstrakcioji", "class_zmogus.html#a2c53378402fbc0c10682d1be34195e3f", null ],
    [ "setPavarde", "class_zmogus.html#a3e3dde4bb34538d1c79df13400ff9299", null ],
    [ "setVardas", "class_zmogus.html#a645bc43b2fa17d7458663fe6e44bbe3c", null ],
    [ "pavarde_", "class_zmogus.html#a95b83ef4d9bbe9b88d78c17563bafa5a", null ],
    [ "vardas_", "class_zmogus.html#a09b290c9be6039ce3a94e1557def9b3a", null ]
];