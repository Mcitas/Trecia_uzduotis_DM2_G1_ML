var files_dup =
[
    [ "v1.5_head.h", "v1_85__head_8h.html", "v1_85__head_8h" ],
    [ "v1.5_main.cpp", "v1_85__main_8cpp.html", "v1_85__main_8cpp" ],
    [ "v1.5_my_func.cpp", "v1_85__my__func_8cpp.html", "v1_85__my__func_8cpp" ]
];