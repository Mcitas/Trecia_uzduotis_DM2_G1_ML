var v1_85__my__func_8cpp =
[
    [ "Failo_generavimas", "v1_85__my__func_8cpp.html#a2c19e8d1223c5c423095f6dbd7027bb7", null ],
    [ "Generuok", "v1_85__my__func_8cpp.html#a8959e80e21db43e450e01ed0283b8c5a", null ],
    [ "IrasykRanka", "v1_85__my__func_8cpp.html#a9055e54c982334cc9de4d2dbcf66799d", null ],
    [ "Isvedimas_i_faila", "v1_85__my__func_8cpp.html#a320333d21091bc6375e5e5f5b15e7614", null ],
    [ "Isvedimas_i_konsole", "v1_85__my__func_8cpp.html#a978905867ae6a4c474ffde55716f9db8", null ],
    [ "palyginimas1", "v1_85__my__func_8cpp.html#aee4a65335a4ba200cc33542101253841", null ],
    [ "palyginimas2", "v1_85__my__func_8cpp.html#a13f5ea9ec27387c68290465a0adac883", null ],
    [ "palyginimas3", "v1_85__my__func_8cpp.html#a4703800abe239b840f82bf31df217a5d", null ],
    [ "Rikiuok", "v1_85__my__func_8cpp.html#ad2ac60e293d91e2c9c1b006113991d2b", null ],
    [ "Rusiuok", "v1_85__my__func_8cpp.html#af4007e85ee48bf1b4dc7782903d3595a", null ],
    [ "Skaiciaus_Ivedimas", "v1_85__my__func_8cpp.html#aae8bce8cdc91a83dc0b703a84519ebee", null ],
    [ "Skaityk", "v1_85__my__func_8cpp.html#afc69870a2072104671e45e1e4b330688", null ],
    [ "VidurkisIrMediana", "v1_85__my__func_8cpp.html#aa7c3328c3fad673969997365336076a6", null ]
];