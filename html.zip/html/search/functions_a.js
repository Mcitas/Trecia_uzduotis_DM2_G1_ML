var searchData=
[
  ['vidurkisirmediana_0',['VidurkisIrMediana',['../v1_85__head_8h.html#aa7c3328c3fad673969997365336076a6',1,'VidurkisIrMediana(int &amp;sum, int &amp;n, Studentas &amp;x, vector&lt; Studentas &gt; &amp;kursas):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#aa7c3328c3fad673969997365336076a6',1,'VidurkisIrMediana(int &amp;sum, int &amp;n, Studentas &amp;x, vector&lt; Studentas &gt; &amp;kursas):&#160;v1.5_my_func.cpp']]]
];
