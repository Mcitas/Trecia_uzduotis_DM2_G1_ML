var searchData=
[
  ['failo_5fgeneravimas_0',['Failo_generavimas',['../v1_85__head_8h.html#a2c19e8d1223c5c423095f6dbd7027bb7',1,'Failo_generavimas(int &amp;m, int &amp;n):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#a2c19e8d1223c5c423095f6dbd7027bb7',1,'Failo_generavimas(int &amp;m, int &amp;n):&#160;v1.5_my_func.cpp']]]
];
