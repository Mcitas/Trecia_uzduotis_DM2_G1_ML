var searchData=
[
  ['generuok_0',['Generuok',['../v1_85__head_8h.html#a8959e80e21db43e450e01ed0283b8c5a',1,'Generuok(Studentas &amp;x, int &amp;n, int &amp;sum, int loginis, int randomizer):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#a8959e80e21db43e450e01ed0283b8c5a',1,'Generuok(Studentas &amp;x, int &amp;n, int &amp;sum, int loginis, int randomizer):&#160;v1.5_my_func.cpp']]],
  ['getbalasm_1',['getBalasm',['../class_studentas.html#a0a8f16edf5b8ee669ecc96aaf444e980',1,'Studentas']]],
  ['getbalasv_2',['getBalasv',['../class_studentas.html#a6369cb8904ac772073a2cebb413e1dc4',1,'Studentas']]],
  ['getegzas_3',['getEgzas',['../class_studentas.html#ae1c5dc290e382c324827aa970dbe17f6',1,'Studentas']]],
  ['getmediana_4',['getMediana',['../class_studentas.html#a4823327b24f27594b50432e01664df87',1,'Studentas']]],
  ['getpavarde_5',['getPavarde',['../class_studentas.html#a5dd7dab43d87cee10ce8b65851adb046',1,'Studentas']]],
  ['getpazymiai_6',['getPazymiai',['../class_studentas.html#a02b6569858027e17ef02ebb0ce886b86',1,'Studentas']]],
  ['getvardas_7',['getVardas',['../class_studentas.html#a7658f22795330130632ac24769a2fd43',1,'Studentas']]]
];
