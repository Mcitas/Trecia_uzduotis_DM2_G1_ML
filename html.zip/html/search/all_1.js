var searchData=
[
  ['clearpazymiai_0',['clearPazymiai',['../class_studentas.html#a9833ccfffe1cbb3b719766bacd0ad46a',1,'Studentas']]]
];
