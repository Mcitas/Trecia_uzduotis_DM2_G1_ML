var searchData=
[
  ['abstrakcioji_0',['abstrakcioji',['../class_zmogus.html#a2c53378402fbc0c10682d1be34195e3f',1,'Zmogus::abstrakcioji()'],['../class_studentas.html#a8d4c360275180feff216c8a51d49e2d0',1,'Studentas::abstrakcioji()']]]
];
