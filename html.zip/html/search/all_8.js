var searchData=
[
  ['rikiuok_0',['Rikiuok',['../v1_85__head_8h.html#ad2ac60e293d91e2c9c1b006113991d2b',1,'Rikiuok(vector&lt; Studentas &gt; &amp;kursas):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#ad2ac60e293d91e2c9c1b006113991d2b',1,'Rikiuok(vector&lt; Studentas &gt; &amp;kursas):&#160;v1.5_my_func.cpp']]],
  ['rusiuok_1',['Rusiuok',['../v1_85__head_8h.html#af4007e85ee48bf1b4dc7782903d3595a',1,'Rusiuok(vector&lt; Studentas &gt; &amp;kursas, vector&lt; Studentas &gt; &amp;vargseliai):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#af4007e85ee48bf1b4dc7782903d3595a',1,'Rusiuok(vector&lt; Studentas &gt; &amp;kursas, vector&lt; Studentas &gt; &amp;vargseliai):&#160;v1.5_my_func.cpp']]]
];
