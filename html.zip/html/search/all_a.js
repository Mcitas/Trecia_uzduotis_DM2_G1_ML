var searchData=
[
  ['v1_2e5_5fhead_2eh_0',['v1.5_head.h',['../v1_85__head_8h.html',1,'']]],
  ['v1_2e5_5fmain_2ecpp_1',['v1.5_main.cpp',['../v1_85__main_8cpp.html',1,'']]],
  ['v1_2e5_5fmy_5ffunc_2ecpp_2',['v1.5_my_func.cpp',['../v1_85__my__func_8cpp.html',1,'']]],
  ['vardas_5f_3',['vardas_',['../class_zmogus.html#a09b290c9be6039ce3a94e1557def9b3a',1,'Zmogus']]],
  ['vidurkisirmediana_4',['VidurkisIrMediana',['../v1_85__head_8h.html#aa7c3328c3fad673969997365336076a6',1,'VidurkisIrMediana(int &amp;sum, int &amp;n, Studentas &amp;x, vector&lt; Studentas &gt; &amp;kursas):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#aa7c3328c3fad673969997365336076a6',1,'VidurkisIrMediana(int &amp;sum, int &amp;n, Studentas &amp;x, vector&lt; Studentas &gt; &amp;kursas):&#160;v1.5_my_func.cpp']]]
];
