var searchData=
[
  ['setbalasm_0',['setBalasm',['../class_studentas.html#acddf531fc0d4659678d6103134af3c51',1,'Studentas']]],
  ['setbalasv_1',['setBalasv',['../class_studentas.html#a971e58e78599fe549404766ddd58a7a5',1,'Studentas']]],
  ['setegzas_2',['setEgzas',['../class_studentas.html#aa32d29e9c73b168a0b9026e8066f595c',1,'Studentas']]],
  ['setmediana_3',['setMediana',['../class_studentas.html#a73d76ddc34fc86841391382b9ca7c3bd',1,'Studentas']]],
  ['setpavarde_4',['setPavarde',['../class_zmogus.html#a3e3dde4bb34538d1c79df13400ff9299',1,'Zmogus::setPavarde()'],['../class_studentas.html#adf50b6cabe54ebd01d298c9690ef5212',1,'Studentas::setPavarde(string pavarde)']]],
  ['setpazymiai_5',['setPazymiai',['../class_studentas.html#aea6fe93231f8c322f6837f55f2b26346',1,'Studentas']]],
  ['setvardas_6',['setVardas',['../class_zmogus.html#a645bc43b2fa17d7458663fe6e44bbe3c',1,'Zmogus::setVardas()'],['../class_studentas.html#a5a490370afdf4aab66b0ce0427e08632',1,'Studentas::setVardas()']]],
  ['skaiciaus_5fivedimas_7',['Skaiciaus_Ivedimas',['../v1_85__head_8h.html#aae8bce8cdc91a83dc0b703a84519ebee',1,'Skaiciaus_Ivedimas(int x1, int x2):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#aae8bce8cdc91a83dc0b703a84519ebee',1,'Skaiciaus_Ivedimas(int x1, int x2):&#160;v1.5_my_func.cpp']]],
  ['skaityk_8',['Skaityk',['../v1_85__head_8h.html#afc69870a2072104671e45e1e4b330688',1,'Skaityk(vector&lt; Studentas &gt; &amp;kursas, int &amp;m, string fpav):&#160;v1.5_my_func.cpp'],['../v1_85__my__func_8cpp.html#afc69870a2072104671e45e1e4b330688',1,'Skaityk(vector&lt; Studentas &gt; &amp;kursas, int &amp;m, string fpav):&#160;v1.5_my_func.cpp']]],
  ['studentas_9',['Studentas',['../class_studentas.html',1,'Studentas'],['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#ad03f446a7aa2dd8c2b20179be349f168',1,'Studentas::Studentas(const Studentas &amp;o)']]]
];
