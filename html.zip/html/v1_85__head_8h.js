var v1_85__head_8h =
[
    [ "Zmogus", "class_zmogus.html", "class_zmogus" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ],
    [ "Failo_generavimas", "v1_85__head_8h.html#a2c19e8d1223c5c423095f6dbd7027bb7", null ],
    [ "Generuok", "v1_85__head_8h.html#a8959e80e21db43e450e01ed0283b8c5a", null ],
    [ "IrasykRanka", "v1_85__head_8h.html#a9055e54c982334cc9de4d2dbcf66799d", null ],
    [ "Isvedimas_i_faila", "v1_85__head_8h.html#a320333d21091bc6375e5e5f5b15e7614", null ],
    [ "Isvedimas_i_konsole", "v1_85__head_8h.html#a978905867ae6a4c474ffde55716f9db8", null ],
    [ "pagalPavarde", "v1_85__head_8h.html#ad1b76acbe9a21f224d81a33126ec3a5b", null ],
    [ "pagalRezultata", "v1_85__head_8h.html#a245bec4f47464f72e96bee1251cb02f3", null ],
    [ "pagalVarda", "v1_85__head_8h.html#ada97411d159ddd21eabd696c77f0ce89", null ],
    [ "Rikiuok", "v1_85__head_8h.html#ad2ac60e293d91e2c9c1b006113991d2b", null ],
    [ "Rusiuok", "v1_85__head_8h.html#af4007e85ee48bf1b4dc7782903d3595a", null ],
    [ "Skaiciaus_Ivedimas", "v1_85__head_8h.html#aae8bce8cdc91a83dc0b703a84519ebee", null ],
    [ "Skaityk", "v1_85__head_8h.html#afc69870a2072104671e45e1e4b330688", null ],
    [ "VidurkisIrMediana", "v1_85__head_8h.html#aa7c3328c3fad673969997365336076a6", null ]
];